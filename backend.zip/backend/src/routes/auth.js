// ============================================================
// FILE: src/routes/auth.js
// Authentication routes — register and login via Supabase Auth
// ============================================================

const express = require("express");
const router = express.Router();
const { supabaseAdmin } = require("../services/supabase");

// Valid roles for registration
const VALID_ROLES = ["tenant", "owner", "scout"];

/**
 * POST /api/auth/register
 * Create a new user with Supabase Auth + profile
 * Body: { name, phone, role, email?, password? }
 *
 * Note: For phone-based auth, Supabase sends an OTP automatically.
 * For MVP, we also support email/password signup as a fallback.
 */
router.post("/register", async (req, res) => {
  const { name, phone, role, email, password } = req.body;

  // Validation
  if (!name || !role) {
    return res.status(400).json({
      error: "Missing required fields",
      required: ["name", "role"],
      optional: ["phone", "email", "password"],
    });
  }

  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({
      error: `Invalid role. Must be one of: ${VALID_ROLES.join(", ")}`,
    });
  }

  // Determine auth method: phone OTP or email/password
  let authResult;

  if (phone) {
    // Phone-based OTP signup
    // Supabase will send an OTP to the phone number
    const { data, error } = await supabaseAdmin.auth.signInWithOtp({
      phone: phone.startsWith("+91") ? phone : `+91${phone}`,
      options: {
        data: { name, role }, // Stored in raw_user_meta_data
      },
    });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    return res.status(200).json({
      message: "OTP sent to your phone number. Use /api/auth/login to verify.",
      phone: phone,
    });
  } else if (email && password) {
    // Email/password signup (fallback for dev/testing)
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm for MVP
      user_metadata: { name, role },
    });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    // The profile is auto-created by the database trigger (handle_new_user)
    // But let's update the phone if provided
    if (phone) {
      await supabaseAdmin
        .from("profiles")
        .update({ phone })
        .eq("id", data.user.id);
    }

    return res.status(201).json({
      message: "Account created successfully",
      user: {
        id: data.user.id,
        email: data.user.email,
        role,
      },
    });
  } else {
    return res.status(400).json({
      error: "Provide either 'phone' for OTP login or 'email' + 'password' for email signup",
    });
  }
});

/**
 * POST /api/auth/login
 * Verify OTP or email/password login
 * Body: { phone, otp } OR { email, password }
 */
router.post("/login", async (req, res) => {
  const { phone, otp, email, password } = req.body;

  let authResult;

  if (phone && otp) {
    // Verify phone OTP
    const { data, error } = await supabaseAdmin.auth.verifyOtp({
      phone: phone.startsWith("+91") ? phone : `+91${phone}`,
      token: otp,
      type: "sms",
    });

    if (error) {
      return res.status(401).json({ error: error.message });
    }

    authResult = data;
  } else if (email && password) {
    // Email/password login
    const { data, error } = await supabaseAdmin.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return res.status(401).json({ error: error.message });
    }

    authResult = data;
  } else {
    return res.status(400).json({
      error: "Provide { phone, otp } or { email, password }",
    });
  }

  // Fetch the user's profile
  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("*")
    .eq("id", authResult.user.id)
    .single();

  return res.status(200).json({
    message: "Login successful",
    session: {
      access_token: authResult.session.access_token,
      refresh_token: authResult.session.refresh_token,
      expires_at: authResult.session.expires_at,
    },
    user: {
      id: authResult.user.id,
      email: authResult.user.email,
      phone: authResult.user.phone,
    },
    profile,
  });
});

module.exports = router;
